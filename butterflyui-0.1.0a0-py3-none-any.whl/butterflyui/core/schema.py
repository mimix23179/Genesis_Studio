from __future__ import annotations

import re
from collections.abc import Mapping
from typing import Any

__all__ = [
    "ValidationError",
    "ButterflyUIContractError",
    "CONTROL_SCHEMAS",
    "FRAME_CHILD_SCHEMA",
    "RUNTIME_PROP_HINTS",
    "validate_props",
    "validate_frame_child",
    "ensure_valid_props",
    "ensure_valid_frame_child",
    "normalize_alignment",
    "normalize_color_matrix",
    "normalize_dimension",
    "normalize_frame",
    "normalize_offset",
    "normalize_padding",
    "normalize_scale",
    "normalize_skew",
]

_DIMENSION_RE = re.compile(r"^[+-]?(?:\d+(?:\.\d+)?|\.\d+)(?:%|px|vw|vh|vmin|vmax)?$")


class ValidationError(ValueError):
    def __init__(self, errors: list[str]) -> None:
        super().__init__("\n".join(errors))
        self.errors = errors


class ButterflyUIContractError(ValidationError):
    pass


def normalize_dimension(value: Any | None) -> Any | None:
    if value is None:
        return None
    if _is_number(value):
        return float(value)
    if isinstance(value, str):
        raw = value.strip()
        if not raw:
            raise ValueError("dimension cannot be empty")
        if not _DIMENSION_RE.match(raw):
            raise ValueError(f"invalid dimension: {value!r}")
        if raw.endswith(("%", "px", "vw", "vh", "vmin", "vmax")):
            return raw
        try:
            return float(raw)
        except ValueError as exc:
            raise ValueError(f"invalid dimension: {value!r}") from exc
    raise TypeError(f"invalid dimension type: {type(value).__name__}")


def normalize_offset(value: Any | None) -> Any | None:
    if value is None:
        return None
    if isinstance(value, (list, tuple)):
        if len(value) < 2:
            raise ValueError("offset must have at least 2 values")
        return [float(value[0]), float(value[1])]
    if isinstance(value, Mapping):
        data: dict[str, Any] = {}
        if "x" in value:
            data["x"] = float(value["x"])
        if "y" in value:
            data["y"] = float(value["y"])
        if not data:
            raise ValueError("offset must include x or y")
        return data
    raise TypeError(f"invalid offset type: {type(value).__name__}")


def normalize_alignment(value: Any | None) -> Any | None:
    if value is None:
        return None
    if isinstance(value, str):
        return value
    return normalize_offset(value)


def normalize_padding(value: Any | None) -> Any | None:
    if value is None:
        return None
    if _is_number(value):
        return float(value)
    if isinstance(value, (list, tuple)):
        if len(value) not in (1, 2, 4):
            raise ValueError("padding must have 1, 2, or 4 values")
        return [float(v) for v in value]
    if isinstance(value, Mapping):
        data: dict[str, Any] = {}
        for key in ("left", "top", "right", "bottom"):
            if key in value:
                data[key] = float(value[key])
        if not data:
            raise ValueError("padding must include at least one edge")
        return data
    raise TypeError(f"invalid padding type: {type(value).__name__}")


def normalize_scale(value: Any | None) -> Any | None:
    if value is None:
        return None
    if _is_number(value):
        return float(value)
    if isinstance(value, (list, tuple)):
        return [float(v) for v in value]
    if isinstance(value, Mapping):
        data = dict(value)
        for key in ("x", "y", "scale_x", "scale_y"):
            if key in data:
                data[key] = float(data[key])
        return data
    raise TypeError(f"invalid scale type: {type(value).__name__}")


def normalize_skew(value: Any | None) -> Any | None:
    if value is None:
        return None
    if _is_number(value):
        return float(value)
    if isinstance(value, (list, tuple)):
        return [float(v) for v in value]
    if isinstance(value, Mapping):
        data = dict(value)
        for key in ("x", "y", "skew_x", "skew_y"):
            if key in data:
                data[key] = float(data[key])
        return data
    raise TypeError(f"invalid skew type: {type(value).__name__}")


def normalize_color_matrix(value: Any | None) -> Any | None:
    if value is None:
        return None
    if isinstance(value, str):
        return value
    if isinstance(value, (list, tuple)):
        if len(value) != 20:
            raise ValueError("color_matrix must have 20 values")
        return [float(v) for v in value]
    raise TypeError(f"invalid color_matrix type: {type(value).__name__}")


def normalize_frame(value: Mapping[str, Any] | None, *, strict: bool = False) -> dict[str, Any]:
    if value is None:
        return {}
    frame: dict[str, Any] = {}
    unknown: list[str] = []
    for key, val in value.items():
        if val is None:
            continue
        if key in ("left", "top", "right", "bottom", "width", "height", "x", "y"):
            frame[key] = normalize_dimension(val)
        elif key in ("anchor", "alignment"):
            frame[key] = normalize_alignment(val)
        elif key in ("z", "z_index"):
            frame[key] = float(val)
        else:
            unknown.append(key)
    if strict and unknown:
        raise ValueError(f"unknown frame keys: {', '.join(unknown)}")
    return frame


def validate_props(control_type: str, props: Mapping[str, Any], *, strict: bool = False) -> list[str]:
    schema = CONTROL_SCHEMAS.get(control_type)
    if schema is None:
        return []
    return _validate_schema(props, schema, path=control_type, strict=strict)


def ensure_valid_props(control_type: str, props: Mapping[str, Any], *, strict: bool = False) -> None:
    errors = validate_props(control_type, props, strict=strict)
    if errors:
        raise ButterflyUIContractError(errors)


def validate_frame_child(frame: Mapping[str, Any], *, strict: bool = False) -> list[str]:
    return _validate_schema(frame, FRAME_CHILD_SCHEMA, path="frame", strict=strict)


def ensure_valid_frame_child(frame: Mapping[str, Any], *, strict: bool = False) -> None:
    errors = validate_frame_child(frame, strict=strict)
    if errors:
        raise ButterflyUIContractError(errors)


def _validate_schema(value: Any, schema: Mapping[str, Any], *, path: str, strict: bool) -> list[str]:
    if value is None:
        return []

    if "anyOf" in schema:
        for option in schema["anyOf"]:
            if not _validate_schema(value, option, path=path, strict=strict):
                return []
        return [f"{path} does not match any allowed schema"]

    if "oneOf" in schema:
        matches = 0
        for option in schema["oneOf"]:
            if not _validate_schema(value, option, path=path, strict=strict):
                matches += 1
        if matches == 1:
            return []
        return [f"{path} does not match exactly one schema"]

    expected_types = schema.get("type")
    if expected_types is not None and not _matches_type(value, expected_types):
        return [f"{path} expected {expected_types}"]

    if "enum" in schema and value not in schema["enum"]:
        return [f"{path} must be one of {schema['enum']}"]

    errors: list[str] = []
    if schema.get("type") == "object" or (
        isinstance(expected_types, list) and "object" in expected_types
    ):
        if not isinstance(value, Mapping):
            return [f"{path} must be an object"]
        props_schema = schema.get("properties", {})
        required = schema.get("required", [])
        for key in required:
            if key not in value:
                errors.append(f"{path}.{key} is required")
        for key, child_value in value.items():
            child_schema = props_schema.get(key)
            if child_schema is not None:
                errors.extend(
                    _validate_schema(child_value, child_schema, path=f"{path}.{key}", strict=strict)
                )
            elif strict and schema.get("additionalProperties") is False:
                errors.append(f"{path}.{key} is not allowed")
        return errors

    if schema.get("type") == "array" or (
        isinstance(expected_types, list) and "array" in expected_types
    ):
        if not isinstance(value, (list, tuple)):
            return [f"{path} must be an array"]
        min_items = schema.get("minItems")
        if min_items is not None and len(value) < min_items:
            errors.append(f"{path} must have at least {min_items} items")
        max_items = schema.get("maxItems")
        if max_items is not None and len(value) > max_items:
            errors.append(f"{path} must have at most {max_items} items")
        items_schema = schema.get("items")
        if items_schema is not None:
            for index, item in enumerate(value):
                errors.extend(
                    _validate_schema(item, items_schema, path=f"{path}[{index}]", strict=strict)
                )
        return errors

    if _is_number(value):
        minimum = schema.get("minimum")
        if minimum is not None and value < minimum:
            errors.append(f"{path} must be >= {minimum}")
        maximum = schema.get("maximum")
        if maximum is not None and value > maximum:
            errors.append(f"{path} must be <= {maximum}")
        return errors

    if isinstance(value, str):
        pattern = schema.get("pattern")
        if pattern and not re.match(pattern, value):
            errors.append(f"{path} does not match pattern {pattern!r}")
        return errors

    return errors


def _matches_type(value: Any, expected: Any) -> bool:
    if isinstance(expected, list):
        return any(_matches_type(value, item) for item in expected)
    if expected == "null":
        return value is None
    if expected == "boolean":
        return isinstance(value, bool)
    if expected == "integer":
        return isinstance(value, int) and not isinstance(value, bool)
    if expected == "number":
        return _is_number(value)
    if expected == "string":
        return isinstance(value, str)
    if expected == "array":
        return isinstance(value, (list, tuple))
    if expected == "object":
        return isinstance(value, Mapping)
    return False


def _is_number(value: Any) -> bool:
    return isinstance(value, (int, float)) and not isinstance(value, bool)


ANY_SCHEMA = {"type": ["null", "boolean", "integer", "number", "string", "object", "array"]}
NUMBER_SCHEMA = {"type": "number"}
INTEGER_SCHEMA = {"type": "integer"}
BOOL_SCHEMA = {"type": "boolean"}
STRING_SCHEMA = {"type": "string"}
ICON_VALUE_SCHEMA = {"type": ["string", "integer"]}

COLOR_SCHEMA = {
    "anyOf": [
        NUMBER_SCHEMA,
        STRING_SCHEMA,
        {
            "type": "object",
            "properties": {
                "r": NUMBER_SCHEMA,
                "g": NUMBER_SCHEMA,
                "b": NUMBER_SCHEMA,
                "a": NUMBER_SCHEMA,
                "red": NUMBER_SCHEMA,
                "green": NUMBER_SCHEMA,
                "blue": NUMBER_SCHEMA,
                "alpha": NUMBER_SCHEMA,
            },
            "additionalProperties": True,
        },
    ]
}

DIMENSION_SCHEMA = {
    "anyOf": [
        NUMBER_SCHEMA,
        {"type": "string", "pattern": _DIMENSION_RE.pattern},
    ]
}

OFFSET_SCHEMA = {
    "anyOf": [
        {"type": "array", "items": NUMBER_SCHEMA, "minItems": 2},
        {
            "type": "object",
            "properties": {"x": NUMBER_SCHEMA, "y": NUMBER_SCHEMA},
            "additionalProperties": True,
        },
    ]
}

ALIGNMENT_SCHEMA = {"anyOf": [STRING_SCHEMA, OFFSET_SCHEMA]}

PADDING_SCHEMA = {
    "anyOf": [
        NUMBER_SCHEMA,
        {"type": "array", "items": NUMBER_SCHEMA, "minItems": 1, "maxItems": 4},
        {
            "type": "object",
            "properties": {
                "left": NUMBER_SCHEMA,
                "top": NUMBER_SCHEMA,
                "right": NUMBER_SCHEMA,
                "bottom": NUMBER_SCHEMA,
            },
            "additionalProperties": True,
        },
    ]
}

LAYOUT_PROPS_SCHEMA = {
    "id": STRING_SCHEMA,
    "key": STRING_SCHEMA,
    "width": DIMENSION_SCHEMA,
    "height": DIMENSION_SCHEMA,
    "min_width": DIMENSION_SCHEMA,
    "min_height": DIMENSION_SCHEMA,
    "max_width": DIMENSION_SCHEMA,
    "max_height": DIMENSION_SCHEMA,
    "left": DIMENSION_SCHEMA,
    "top": DIMENSION_SCHEMA,
    "right": DIMENSION_SCHEMA,
    "bottom": DIMENSION_SCHEMA,
    "x": DIMENSION_SCHEMA,
    "y": DIMENSION_SCHEMA,
    "z": NUMBER_SCHEMA,
    "z_index": NUMBER_SCHEMA,
    "padding": PADDING_SCHEMA,
    "margin": PADDING_SCHEMA,
    "alignment": ALIGNMENT_SCHEMA,
    "anchor": ALIGNMENT_SCHEMA,
    "expand": BOOL_SCHEMA,
    "expand_loose": BOOL_SCHEMA,
    "visible": BOOL_SCHEMA,
    "opacity": NUMBER_SCHEMA,
}

UNIVERSAL_PROPS_SCHEMA = {
    "child": ANY_SCHEMA,
    "children": {"type": "array", "items": ANY_SCHEMA},
    "enabled": BOOL_SCHEMA,
    "disabled": BOOL_SCHEMA,
    "style": {"type": "object", "additionalProperties": ANY_SCHEMA},
    "style_slots": {"type": "object", "additionalProperties": ANY_SCHEMA},
    "modifiers": {"type": "array", "items": ANY_SCHEMA},
    "motion": ANY_SCHEMA,
    "state": STRING_SCHEMA,
    "variant": ANY_SCHEMA,
    "events": {"type": "array", "items": STRING_SCHEMA},
    "tooltip": STRING_SCHEMA,
    "cursor": STRING_SCHEMA,
    "semantics": {"type": "object", "additionalProperties": ANY_SCHEMA},
    "accessibility": {"type": "object", "additionalProperties": ANY_SCHEMA},
    "aria_label": STRING_SCHEMA,
    "data": {"type": "object", "additionalProperties": ANY_SCHEMA},
}


def _control_schema(props: Mapping[str, Any] | None = None, *, additional: bool = True) -> dict[str, Any]:
    merged = dict(props or {})
    return {"type": "object", "properties": merged, "additionalProperties": additional}


def _merge_layout(schema: dict[str, Any]) -> dict[str, Any]:
    props = dict(LAYOUT_PROPS_SCHEMA)
    props.update(schema.get("properties", {}))
    schema["properties"] = props
    schema.setdefault("additionalProperties", True)
    return schema


def _merge_universal(schema: dict[str, Any]) -> dict[str, Any]:
    props = dict(UNIVERSAL_PROPS_SCHEMA)
    props.update(schema.get("properties", {}))
    schema["properties"] = props
    schema.setdefault("additionalProperties", True)
    return schema


FRAME_CHILD_SCHEMA = _control_schema(
    {
        "control": ANY_SCHEMA,
        "props": {"type": "object", "additionalProperties": ANY_SCHEMA},
        "frame": _control_schema(
            {
                "left": DIMENSION_SCHEMA,
                "top": DIMENSION_SCHEMA,
                "right": DIMENSION_SCHEMA,
                "bottom": DIMENSION_SCHEMA,
                "width": DIMENSION_SCHEMA,
                "height": DIMENSION_SCHEMA,
                "x": DIMENSION_SCHEMA,
                "y": DIMENSION_SCHEMA,
                "anchor": ALIGNMENT_SCHEMA,
                "alignment": ALIGNMENT_SCHEMA,
                "z": NUMBER_SCHEMA,
                "z_index": NUMBER_SCHEMA,
            }
        ),
    }
)


_BOTH_ENDS_CONTROL_TYPES = ['accordion',
 'action_bar',
 'alert_dialog',
 'align',
 'animated_background',
 'animated_gradient',
 'animation',
 'app_bar',
 'artifact_card',
 'aspect_ratio',
 'async_action_button',
 'audio',
 'avatar',
 'avatar_stack',
 'badge',
 'bar_chart',
 'bar_plot',
 'blend_mode_picker',
 'blob_field',
 'border',
 'border_side',
 'bottom_sheet',
 'box',
 'breadcrumb_bar',
 'bubble',
 'button',
 'button_style',
 'candy',
 'candy_scope',
 'canvas',
 'card',
 'center',
 'chart',
 'checkbox',
 'chip',
 'chromatic_shift',
 'clip',
 'color_picker',
 'color_tools',
 'column',
 'combo_box',
 'confetti_burst',
 'container',
 'container_style',
 'context_menu',
 'crop_box',
 'data_grid',
 'data_source_view',
 'data_table',
 'date_picker',
 'decorated_box',
 'directory_picker',
 'display',
 'divider',
 'drag_handle',
 'drawer',
 'drop_zone',
 'dropdown',
 'effects',
 'elevated_button',
 'emoji_icon',
 'emoji_picker',
 'expanded',
 'field_group',
 'file_picker',
 'filled_button',
 'fitted_box',
 'flex_spacer',
 'flow_field',
 'fold_layer',
 'form',
 'form_field',
 'frame',
 'gallery',
 'gallery_scope',
 'gesture_area',
 'glass_blur',
 'glow_effect',
 'glyph_button',
 'gradient',
 'gradient_editor',
 'gradient_sweep',
 'grain_overlay',
 'grid',
 'grid_view',
 'histogram_overlay',
 'histogram_view',
 'hover_region',
 'html_view',
 'icon',
 'icon_button',
 'icon_picker',
 'image',
 'item_tile',
 'key_listener',
 'keybind_recorder',
 'line_chart',
 'line_plot',
 'liquid_morph',
 'list_tile',
 'list_view',
 'markdown_view',
 'menu_bar',
 'menu_item',
 'modifier',
 'morphing_border',
 'motion',
 'nav_ring',
 'neon_edge',
 'noise_displacement',
 'noise_field',
 'notice_bar',
 'notification_center',
 'option',
 'outline',
 'outlined_button',
 'overlay',
 'page_view',
 'pagination',
 'pane',
 'parallax',
 'particle_field',
 'particles',
 'pie_plot',
 'pixelate',
 'popover',
 'portal',
 'pressable',
 'preview_surface',
 'progress_bar',
 'progress_ring',
 'radio',
 'rail_nav',
 'reorderable_list_view',
 'ripple_burst',
 'route',
 'row',
 'safe_area',
 'scanline_overlay',
 'scene_view',
 'scroll_view',
 'scrollable_column',
 'scrollable_row',
 'select',
 'shadow',
 'shadow_stack',
 'shimmer',
 'shimmer_shadow',
 'sidebar',
 'skins',
 'skins_scope',
 'slide_panel',
 'slider',
 'snack_bar',
 'snap_grid',
 'sortable_header',
 'spacer',
 'spark_plot',
 'sparkline',
 'splash',
 'split_pane',
 'split_view',
 'sprite',
 'stack',
 'stagger',
 'status_bar',
 'sticky_list',
 'style',
 'surface',
 'switch',
 'table',
 'table_view',
 'tabs',
 'text',
 'text_area',
 'text_button',
 'text_field',
 'time_select',
 'timeline',
 'toast',
 'toast_host',
 'tooltip',
 'top_bar',
 'transition',
 'vertical_divider',
 'video',
 'vignette',
 'virtual_grid',
 'virtual_list',
 'visual_fx',
 'webview',
 'window_controls',
 'window_drag_region',
 'window_frame',
 'wrap']


def _typed_schema_overrides() -> dict[str, dict[str, Any]]:
    return {
        "alert_dialog": _control_schema({
            "open": BOOL_SCHEMA,
            "dismissible": BOOL_SCHEMA,
            "close_on_escape": BOOL_SCHEMA,
            "trap_focus": BOOL_SCHEMA,
            "duration_ms": INTEGER_SCHEMA,
            "transition": {"type": "object", "additionalProperties": ANY_SCHEMA},
            "transition_type": STRING_SCHEMA,
            "source_rect": ANY_SCHEMA,
            "scrim_color": COLOR_SCHEMA,
            "title": ANY_SCHEMA,
            "content": ANY_SCHEMA,
            "actions": {"type": "array", "items": ANY_SCHEMA},
        }),
        "bubble": _control_schema({
            "variant": STRING_SCHEMA,
            "role": STRING_SCHEMA,
            "tone": STRING_SCHEMA,
            "density": STRING_SCHEMA,
            "align": STRING_SCHEMA,
            "text": STRING_SCHEMA,
            "value": STRING_SCHEMA,
            "markdown": ANY_SCHEMA,
            "messages": {"type": "array", "items": ANY_SCHEMA},
            "items": {"type": "array", "items": ANY_SCHEMA},
            "attachments": {"type": "array", "items": ANY_SCHEMA},
            "reactions": {"type": "array", "items": ANY_SCHEMA},
            "actions": {"type": "array", "items": ANY_SCHEMA},
            "min_lines": INTEGER_SCHEMA,
            "max_lines": INTEGER_SCHEMA,
            "send_on_enter": BOOL_SCHEMA,
            "show_input": BOOL_SCHEMA,
            "show_attach": BOOL_SCHEMA,
            "disabled": BOOL_SCHEMA,
            "read_only": BOOL_SCHEMA,
        }),
        "candy_scope": _control_schema({
            "tokens": {"type": "object", "additionalProperties": ANY_SCHEMA},
            "theme": {"type": "object", "additionalProperties": ANY_SCHEMA},
            "brightness": STRING_SCHEMA,
            "child": ANY_SCHEMA,
            "children": {"type": "array", "items": ANY_SCHEMA},
            "particles": BOOL_SCHEMA,
            "scanline": BOOL_SCHEMA,
            "shimmer": BOOL_SCHEMA,
            "vignette": BOOL_SCHEMA,
        }),
        "display": _control_schema({
            "role": STRING_SCHEMA,
            "variant": STRING_SCHEMA,
            "title": STRING_SCHEMA,
            "subtitle": STRING_SCHEMA,
            "caption": STRING_SCHEMA,
            "description": STRING_SCHEMA,
            "tone": STRING_SCHEMA,
            "size": STRING_SCHEMA,
            "interactive": BOOL_SCHEMA,
            "value": ANY_SCHEMA,
            "items": {"type": "array", "items": ANY_SCHEMA},
            "selected": {"type": "array", "items": ANY_SCHEMA},
            "checked": {"type": "array", "items": ANY_SCHEMA},
        }),
        "modifier": _control_schema({
            "modifiers": {"type": "array", "items": ANY_SCHEMA},
            "on_hover": {"type": "array", "items": ANY_SCHEMA},
            "on_pressed": {"type": "array", "items": ANY_SCHEMA},
            "on_focus": {"type": "array", "items": ANY_SCHEMA},
            "motion": ANY_SCHEMA,
            "cursor": STRING_SCHEMA,
            "padding": PADDING_SCHEMA,
            "margin": PADDING_SCHEMA,
            "align": ALIGNMENT_SCHEMA,
            "border": ANY_SCHEMA,
            "background": ANY_SCHEMA,
            "shadow": ANY_SCHEMA,
            "glow": ANY_SCHEMA,
            "glass": ANY_SCHEMA,
            "focus_ring": ANY_SCHEMA,
            "hit_test": STRING_SCHEMA,
        }),
        "page_view": _control_schema({
            "index": INTEGER_SCHEMA,
            "initial_page": INTEGER_SCHEMA,
            "animate": BOOL_SCHEMA,
            "duration_ms": INTEGER_SCHEMA,
            "keep_alive": BOOL_SCHEMA,
            "scroll_direction": STRING_SCHEMA,
            "reverse": BOOL_SCHEMA,
            "page_snapping": BOOL_SCHEMA,
            "pad_ends": BOOL_SCHEMA,
            "viewport_fraction": NUMBER_SCHEMA,
        }),
        "pagination": _control_schema({
            "page": INTEGER_SCHEMA,
            "page_count": INTEGER_SCHEMA,
            "page_size": INTEGER_SCHEMA,
            "total_items": INTEGER_SCHEMA,
            "max_visible": INTEGER_SCHEMA,
            "show_edges": BOOL_SCHEMA,
            "dense": BOOL_SCHEMA,
            "enabled": BOOL_SCHEMA,
            "prev_label": STRING_SCHEMA,
            "next_label": STRING_SCHEMA,
            "mode": STRING_SCHEMA,
        }),
        "progress_bar": _control_schema({
            "value": NUMBER_SCHEMA,
            "indeterminate": BOOL_SCHEMA,
            "label": STRING_SCHEMA,
            "stroke_width": NUMBER_SCHEMA,
            "variant": STRING_SCHEMA,
            "circular": BOOL_SCHEMA,
        }),
        "progress_ring": _control_schema({
            "value": NUMBER_SCHEMA,
            "indeterminate": BOOL_SCHEMA,
            "label": STRING_SCHEMA,
            "stroke_width": NUMBER_SCHEMA,
            "variant": STRING_SCHEMA,
            "circular": BOOL_SCHEMA,
        }),
        "reorderable_list_view": _control_schema({
            "items": {"type": "array", "items": ANY_SCHEMA},
            "dense": BOOL_SCHEMA,
        }),
        "snack_bar": _control_schema({
            "message": STRING_SCHEMA,
            "label": STRING_SCHEMA,
            "open": BOOL_SCHEMA,
            "duration_ms": INTEGER_SCHEMA,
            "action_label": STRING_SCHEMA,
            "variant": STRING_SCHEMA,
            "style": STRING_SCHEMA,
            "icon": ICON_VALUE_SCHEMA,
            "instant": BOOL_SCHEMA,
            "priority": INTEGER_SCHEMA,
            "use_flushbar": BOOL_SCHEMA,
            "use_fluttertoast": BOOL_SCHEMA,
            "toast_position": STRING_SCHEMA,
        }),
        "skins_scope": _control_schema({
            "skin": STRING_SCHEMA,
            "tokens": {"type": "object", "additionalProperties": ANY_SCHEMA},
            "brightness": STRING_SCHEMA,
            "child": ANY_SCHEMA,
            "children": {"type": "array", "items": ANY_SCHEMA},
        }),
        "style": _control_schema({
            "style_pack": STRING_SCHEMA,
            "pack": STRING_SCHEMA,
            "tokens": {"type": "object", "additionalProperties": ANY_SCHEMA},
            "token_overrides": {"type": "object", "additionalProperties": ANY_SCHEMA},
            "style_tokens": {"type": "object", "additionalProperties": ANY_SCHEMA},
            "recipes": {"type": "object", "additionalProperties": ANY_SCHEMA},
            "default_style": {"type": "object", "additionalProperties": ANY_SCHEMA},
            "default_modifiers": {"type": "array", "items": ANY_SCHEMA},
            "default_motion": ANY_SCHEMA,
            "state": STRING_SCHEMA,
        }),
        "vertical_divider": _control_schema({
            "vertical": BOOL_SCHEMA,
            "thickness": NUMBER_SCHEMA,
            "indent": NUMBER_SCHEMA,
            "end_indent": NUMBER_SCHEMA,
            "color": COLOR_SCHEMA,
        }),
    }


_TYPED_SCHEMA_OVERRIDES = _typed_schema_overrides()

CONTROL_SCHEMAS: dict[str, dict[str, Any]] = {
    name: _TYPED_SCHEMA_OVERRIDES.get(name, _control_schema())
    for name in _BOTH_ENDS_CONTROL_TYPES
}

RUNTIME_PROP_HINTS: dict[str, list[str]] = {'accordion': ['accent_color',
               'allowEmpty',
               'allow_empty',
               'body_color',
               'body_padding',
               'border_color',
               'content_padding',
               'dense',
               'divider_color',
               'elevation',
               'expanded',
               'glass_blur',
               'glass_opacity',
               'header_bg',
               'header_color',
               'header_padding',
               'index',
               'labels',
               'multiple',
               'radius',
               'show_dividers',
               'spacing',
               'style',
               'variant'],
 'action_bar': ['bgcolor',
                'spacing',
                'items',
                'open',
                'anchor',
                'position',
                'offset',
                'dismissible',
                'scrim_color',
                'text_color',
                'icon_color',
                'item_bgcolor',
                'padding',
                'alignment',
                'backdrop',
                'backdrop_blur'],
 'alert_dialog': ['open',
                  'dismissible',
                  'close_on_escape',
                  'trap_focus',
                  'duration_ms',
                  'transition',
                  'transition_type',
                  'source_rect',
                  'scrim_color',
                  'title',
                  'content',
                  'actions',
                  'child'],
 'align': [],
 'animated_background': [],
 'animated_gradient': [],
 'animation': ['duration_ms', 'curve', 'opacity', 'scale', 'offset', 'rotation', 'enabled', 'child', 'children'],
 'app_bar': [],
 'artifact_card': [],
 'aspect_ratio': ['ratio', 'aspect_ratio', 'child'],
 'async_action_button': ['label',
                         'state',
                         'enabled',
                         'variant',
                         'color',
                         'text_color',
                         'radius',
                         'content_padding',
                         'success_label',
                         'error_label',
                         'progress',
                         'show_progress',
                         'text',
                         'value',
                         'busy',
                         'loading',
                         'disabled_while_busy',
                         'busy_label',
                         'window_action',
                         'window_action_delay_ms',
                         'action',
                         'actions',
                         'action_id',
                         'action_event',
                         'action_payload'],
 'audio': [],
 'avatar': ['src',
            'image',
            'name',
            'initials',
            'icon',
            'size',
            'radius',
            'color',
            'bgcolor',
            'status',
            'badge',
            'enabled'],
 'avatar_stack': ['avatars', 'items', 'size', 'overlap', 'max'],
 'badge': ['label', 'text', 'value', 'color', 'bgcolor', 'offset', 'radius', 'text_color', 'padding', 'clickable'],
 'bar_chart': [],
 'bar_plot': ['color', 'colors', 'max', 'min', 'spacing', 'values'],
 'blend_mode_picker': ['value', 'options', 'items', 'label', 'enabled', 'dense'],
 'blob_field': ['count', 'seed', 'color', 'background', 'bgcolor'],
 'border': ['color', 'width', 'radius', 'side', 'padding'],
 'border_side': ['side', 'color', 'width', 'length'],
 'bottom_sheet': [],
 'box': ['color',
         'bgcolor',
         'padding',
         'margin',
         'alignment',
         'radius',
         'border',
         'border_color',
         'border_width',
         'clip_behavior',
         'gradient',
         'image'],
 'breadcrumb_bar': [],
 'bubble': ['variant',
            'role',
            'tone',
            'density',
            'compact',
            'dense',
            'align',
            'max_width',
            'grouping',
            'group_messages',
            'grouped',
            'selectable',
            'clickable',
            'sender_name',
            'author',
            'avatar',
            'role_badge',
            'title',
            'subtitle',
            'text',
            'markdown',
            'timestamp',
            'edited',
            'delivered',
            'read',
            'status',
            'error_notice',
            'notice',
            'attachments',
            'reactions',
            'actions',
            'quote_text',
            'quote_author',
            'quote_timestamp',
            'mention_label',
            'mention_color',
            'mention_text_color',
            'mention_clickable',
            'divider_label',
            'divider_color',
            'messages',
            'items',
            'pinned_messages',
            'spacing',
            'reverse',
            'scrollable',
            'autoscroll',
            'follow_latest',
            'unread_divider_label',
            'unread_after_id',
            'unread_index',
            'date_separators',
            'empty_state',
            'typing_indicator',
            'show_timestamps',
            'show_input',
            'input_placeholder',
            'send_label',
            'send_on_enter',
            'value',
            'placeholder',
            'min_lines',
            'max_lines',
            'auto_expand',
            'leading',
            'trailing',
            'show_attach',
            'draft_key',
            'char_limit',
            'show_counter',
            'cooldown_ms',
            'disabled',
            'read_only',
            'emit_on_change',
            'clear_on_send',
            'events',
            'line_color',
            'content',
            'enabled',
            'use_flutter_chat_ui',
            'user_id',
            'multiline',
            'submit_label',
            'show_send'],
 'button': ['window_action',
            'window_action_delay_ms',
            'action',
            'actions',
            'action_id',
            'action_event',
            'action_payload',
            'value'],
 'button_style': ['value',
                  'options',
                  'items',
                  'base',
                  'hover',
                  'pressed',
                  'disabled',
                  'focus_ring',
                  'motion_behavior',
                  'action',
                  'actions',
                  'action_id',
                  'action_event',
                  'action_payload'],
 'candy': ['schema_version',
           'module',
           'variant',
           'events',
           'state',
           'payload',
           'theme',
           'tokens',
           'token_overrides',
           'modules',
           'slots',
           'semantics',
           'accessibility',
           'interaction',
           'performance',
           'quality',
           'cache',
           'button',
           'card',
           'column',
           'container',
           'row',
           'stack',
           'surface',
           'wrap',
           'align',
           'center',
           'spacer',
           'aspect_ratio',
           'overflow_box',
           'fitted_box',
           'effects',
           'particles',
           'border',
           'shadow',
           'outline',
           'gradient',
           'animation',
           'transition',
           'canvas',
           'clip',
           'decorated_box',
           'badge',
           'avatar',
           'icon',
           'text',
           'motion'],
 'canvas': [],
 'card': ['color',
          'elevation',
          'radius',
          'margin',
          'padding',
          'shape',
          'clip_behavior',
          'surface_tint_color',
          'shadow_color'],
 'center': [],
 'chart': [],
 'checkbox': [],
 'chip': [],
 'chromatic_shift': ['shift', 'opacity'],
 'clip': ['shape', 'radius', 'clip_behavior', 'child'],
 'color_picker': ['value',
                  'color',
                  'mode',
                  'picker_mode',
                  'show_alpha',
                  'alpha',
                  'presets',
                  'emit_on_change',
                  'show_actions',
                  'show_input',
                  'show_hex',
                  'show_presets',
                  'preset_size',
                  'preset_spacing',
                  'preview_height',
                  'input_label',
                  'input_placeholder',
                  'enabled',
                  'commit_text',
                  'cancel_text'],
 'color_tools': [],
 'column': ['spacing',
            'alignment',
            'horizontal_alignment',
            'vertical_alignment',
            'run_alignment',
            'reverse',
            'clip_behavior'],
 'combo_box': ['value',
               'options',
               'items',
               'groups',
               'label',
               'hint',
               'placeholder',
               'loading',
               'async_source',
               'debounce_ms',
               'enabled'],
 'confetti_burst': ['colors', 'count', 'duration_ms', 'gravity'],
 'container': [],
 'container_style': ['variant',
                     'outline_width',
                     'outline_color',
                     'stroke_width',
                     'stroke_color',
                     'shadow_color',
                     'shadow_blur',
                     'shadow_dx',
                     'shadow_dy',
                     'glow_color',
                     'glow_blur',
                     'bgcolor',
                     'background',
                     'bg_color',
                     'border_color',
                     'border_width',
                     'radius',
                     'shape',
                     'content_padding',
                     'inner_padding',
                     'icon_padding',
                     'animation'],
 'context_menu': ['items',
                  'bgcolor',
                  'text_color',
                  'icon_color',
                  'item_bgcolor',
                  'divider_color',
                  'backdrop',
                  'backdrop_blur',
                  'use_contextmenu'],
 'crop_box': [],
 'data_grid': ['rows',
               'columns',
               'sortable',
               'filterable',
               'selectable',
               'multi_select',
               'pagination',
               'page_size',
               'dense',
               'striped',
               'show_header',
               'auto_sort',
               'selected_index',
               'sort_column',
               'sort_ascending',
               'filter_query',
               'filter_column',
               'filter_case_sensitive'],
 'data_source_view': ['state',
                      'loading',
                      'page',
                      'page_size',
                      'has_more',
                      'refreshable',
                      'prefetch_threshold',
                      'cache_key',
                      'show_content_on_loading',
                      'overlay_loading',
                      'empty_view',
                      'error_view',
                      'offline_view',
                      'loading_view'],
 'data_table': [],
 'date_picker': ['enabled', 'label', 'max_date', 'min_date', 'placeholder', 'value', 'end', 'start'],
 'decorated_box': ['color',
                   'bgcolor',
                   'gradient',
                   'image',
                   'border_color',
                   'border_width',
                   'radius',
                   'shape',
                   'shadow',
                   'padding',
                   'margin',
                   'clip_behavior',
                   'child',
                   'children'],
 'directory_picker': ['label',
                      'mode',
                      'pick_directory',
                      'enabled',
                      'initial_directory',
                      'dialog_title',
                      'lock_parent_window'],
 'display': ['role',
             'variant',
             'title',
             'subtitle',
             'caption',
             'description',
             'name',
             'tone',
             'size',
             'interactive',
             'icon',
             'leading',
             'trailing',
             'avatar',
             'initials',
             'tags',
             'status',
             'badge',
             'color',
             'value',
             'max',
             'allow_half',
             'count',
             'items',
             'selected',
             'checked',
             'checked_value',
             'dot_count',
             'document_id',
             'ranges',
             'owners',
             'owner',
             'show_avatars',
             'compact',
             'dense',
             'aria_label',
             'events',
             'bgcolor',
             'border_color',
             'border_width',
             'label',
             'src',
             'text_color',
             'rating',
             'max_rating',
             'show_count',
             'inactive_color',
             'dot_size',
             'text',
             'enabled',
             'indices',
             'options',
             'spacing',
             'values'],
 'divider': ['vertical', 'thickness', 'indent', 'end_indent', 'color'],
 'drag_handle': [],
 'drawer': [],
 'drop_zone': ['enabled', 'accepts', 'title', 'subtitle', 'use_desktop_drop'],
 'dropdown': [],
 'effects': ['blur',
             'opacity',
             'color',
             'blend_mode',
             'brightness',
             'contrast',
             'saturation',
             'hue_rotate',
             'grayscale',
             'enabled',
             'child',
             'children'],
 'elevated_button': [],
 'emoji_icon': ['emoji',
                'text',
                'size',
                'variant',
                'color',
                'text_color',
                'fgcolor',
                'outline_width',
                'stroke_width',
                'outline_color',
                'stroke_color',
                'shadow_color',
                'glow_color',
                'shadow_blur',
                'glow_blur',
                'shadow_dx',
                'shadow_dy',
                'bgcolor',
                'background',
                'bg_color',
                'border_color',
                'border_width',
                'content_padding',
                'inner_padding',
                'icon_padding',
                'radius',
                'shape'],
 'emoji_picker': [],
 'expanded': [],
 'field_group': ['error_text', 'helper_text', 'label', 'spacing'],
 'file_picker': ['label',
                 'file_type',
                 'extensions',
                 'allowed_extensions',
                 'multiple',
                 'allow_multiple',
                 'with_data',
                 'with_path',
                 'enabled',
                 'mode',
                 'pick_directory',
                 'save_file',
                 'file_name',
                 'dialog_title',
                 'initial_directory',
                 'lock_parent_window',
                 'show_selection'],
 'filled_button': [],
 'fitted_box': ['fit', 'alignment', 'clip_behavior', 'child'],
 'flex_spacer': [],
 'flow_field': [],
 'fold_layer': [],
 'form': ['description', 'spacing', 'title'],
 'form_field': [],
 'frame': [],
 'gallery': ['schema_version',
             'module',
             'state',
             'items',
             'spacing',
             'run_spacing',
             'tile_width',
             'tile_height',
             'selectable',
             'enabled',
             'events',
             'modules',
             'manifest',
             'registries',
             'toolbar',
             'filter_bar',
             'grid_layout',
             'item_actions',
             'item_badge',
             'item_meta_row',
             'item_preview',
             'item_selectable',
             'item_tile',
             'pagination',
             'section_header',
             'sort_bar',
             'empty_state',
             'loading_skeleton',
             'search_bar',
             'font_picker',
             'audio_picker',
             'video_picker',
             'image_picker',
             'document_picker',
             'fonts',
             'font_renderer',
             'audio',
             'audio_renderer',
             'video',
             'video_renderer',
             'image',
             'image_renderer',
             'document',
             'document_renderer',
             'item_drag_handle',
             'item_drop_target',
             'item_reorder_handle',
             'item_selection_checkbox',
             'item_selection_radio',
             'item_selection_switch',
             'apply',
             'clear',
             'select_all',
             'deselect_all',
             'apply_font',
             'apply_image',
             'set_as_wallpaper',
             'presets',
             'skins',
             'payload'],
 'gallery_scope': ['layout',
                   'spacing',
                   'radius',
                   'columns',
                   'cross_axis_count',
                   'cross_axis_spacing',
                   'main_axis_spacing'],
 'gesture_area': [],
 'glass_blur': ['blur', 'opacity', 'color', 'radius', 'border_color', 'border_width'],
 'glow_effect': ['color', 'blur', 'spread', 'radius', 'offset_x', 'offset_y', 'clip'],
 'glyph_button': ['bgcolor', 'color', 'enabled', 'icon', 'size', 'tooltip'],
 'gradient': ['variant',
              'colors',
              'stops',
              'tile_mode',
              'begin',
              'end',
              'center',
              'radius',
              'focal',
              'focal_radius',
              'start_angle',
              'end_angle',
              'start_degrees',
              'end_degrees',
              'bgcolor',
              'background',
              'background_color',
              'opacity',
              'mesh',
              'mesh_points',
              'points'],
 'gradient_editor': ['stops', 'angle', 'show_angle', 'show_add', 'show_remove'],
 'gradient_sweep': ['colors', 'duration_ms', 'angle', 'opacity'],
 'grain_overlay': [],
 'grid': ['columns',
          'spacing',
          'run_spacing',
          'child_aspect_ratio',
          'layout',
          'masonry',
          'scrollable',
          'virtual',
          'virtualized'],
 'grid_view': [],
 'histogram_overlay': [],
 'histogram_view': [],
 'hover_region': ['cursor', 'enabled'],
 'html_view': [],
 'icon': [],
 'icon_button': ['icon',
                 'glyph',
                 'tooltip',
                 'size',
                 'color',
                 'enabled',
                 'value',
                 'action',
                 'actions',
                 'action_id',
                 'action_event',
                 'action_payload'],
 'icon_picker': [],
 'image': ['src', 'fit', 'radius', 'cache', 'placeholder'],
 'item_tile': ['dense',
               'enabled',
               'leading_icon',
               'leading_text',
               'leading_image',
               'selected',
               'subtitle',
               'title',
               'meta',
               'badges',
               'actions',
               'trailing_icon',
               'trailing_text'],
 'key_listener': ['autofocus', 'enabled'],
 'keybind_recorder': [],
 'line_chart': [],
 'line_plot': ['color', 'fill', 'fill_color', 'max', 'min', 'stroke_width', 'values'],
 'liquid_morph': [],
 'list_tile': ['dense',
               'enabled',
               'leading_icon',
               'leading_text',
               'leading_image',
               'selected',
               'subtitle',
               'title',
               'meta',
               'badges',
               'actions',
               'trailing_icon',
               'trailing_text'],
 'list_view': [],
 'markdown_view': ['value', 'text', 'selectable', 'scrollable', 'use_flutter_markdown'],
 'menu_bar': ['menus',
              'items',
              'bgcolor',
              'text_color',
              'icon_color',
              'item_bgcolor',
              'divider_color',
              'height',
              'dense',
              'padding',
              'backdrop',
              'backdrop_blur',
              'use_menu_bar',
              'use_mac_menu_bar'],
 'menu_item': ['id', 'label', 'title', 'icon', 'shortcut', 'enabled', 'selected'],
 'modifier': ['modifiers',
              'motion',
              'on_hover',
              'on_pressed',
              'on_focus',
              'cursor',
              'padding',
              'margin',
              'align',
              'max_width',
              'max_height',
              'min_width',
              'min_height',
              'border',
              'background',
              'shadow',
              'glow',
              'glass',
              'focus_ring',
              'hit_test',
              'events',
              'child',
              'children'],
 'morphing_border': [],
 'motion': [],
 'nav_ring': ['policy'],
 'neon_edge': [],
 'noise_displacement': [],
 'noise_field': [],
 'notice_bar': ['action_id', 'action_label', 'dismissible', 'icon', 'text', 'variant'],
 'notification_center': [],
 'option': [],
 'outline': [],
 'outlined_button': [],
 'overlay': ['base',
             'overlays',
             'layers',
             'clip',
             'transition',
             'transition_type',
             'transition_ms',
             'active_overlay',
             'active_id',
             'overlay_id',
             'active_index',
             'index',
             'show_all_overlays',
             'show_default_overlay',
             'max_visible_overlays',
             'value'],
 'page_view': ['index',
               'initial_page',
               'animate',
               'duration_ms',
               'keep_alive',
               'scroll_direction',
               'reverse',
               'page_snapping',
               'pad_ends',
               'viewport_fraction',
               'events',
               'child',
               'children'],
 'pagination': ['page',
                'page_count',
                'page_size',
                'total_items',
                'max_visible',
                'show_edges',
                'dense',
                'enabled',
                'prev_label',
                'next_label',
                'mode',
                'events'],
 'pane': [],
 'parallax': [],
 'particle_field': ['count',
                    'speed',
                    'size',
                    'colors',
                    'seed',
                    'gravity',
                    'drift',
                    'link_distance',
                    'line_color',
                    'line_opacity',
                    'play',
                    'enabled'],
 'particles': ['count',
               'colors',
               'min_size',
               'max_size',
               'speed',
               'min_speed',
               'max_speed',
               'direction',
               'spread',
               'opacity',
               'seed',
               'loop',
               'play',
               'shape'],
 'pie_plot': ['colors', 'inner_radius', 'start_angle', 'values'],
 'pixelate': [],
 'popover': ['anchor',
             'content',
             'open',
             'position',
             'offset',
             'dismissible',
             'scrim_color',
             'transition',
             'transition_type',
             'duration_ms'],
 'portal': [],
 'pressable': ['enabled'],
 'preview_surface': [],
 'progress_bar': ['value', 'indeterminate', 'label', 'stroke_width', 'variant', 'circular'],
 'progress_ring': ['value', 'indeterminate', 'label', 'stroke_width', 'variant', 'circular'],
 'radio': [],
 'rail_nav': ['items'],
 'reorderable_list_view': ['items', 'dense', 'events'],
 'ripple_burst': [],
 'route': ['route_id', 'title', 'label', 'child', 'children', 'layout', 'spacing'],
 'row': ['spacing',
         'alignment',
         'horizontal_alignment',
         'vertical_alignment',
         'run_alignment',
         'wrap',
         'reverse',
         'clip_behavior'],
 'safe_area': [],
 'scanline_overlay': ['enabled', 'opacity', 'line_thickness', 'spacing', 'angle', 'speed', 'blend_mode', 'color'],
 'scene_view': ['background', 'show_grid'],
 'scroll_view': ['axis',
                 'reverse',
                 'primary',
                 'physics',
                 'padding',
                 'controller_id',
                 'scrollbar',
                 'thumb_visibility',
                 'track_visibility',
                 'initial_offset'],
 'scrollable_column': [],
 'scrollable_row': [],
 'select': [],
 'shadow': ['color', 'blur', 'spread', 'offset_x', 'offset_y', 'radius', 'shadows', 'child'],
 'shadow_stack': [],
 'shimmer': [],
 'shimmer_shadow': [],
 'sidebar': [],
 'skins': ['schema_version',
           'module',
           'state',
           'skins',
           'selected_skin',
           'presets',
           'value',
           'enabled',
           'events',
           'modules',
           'manifest',
           'registries',
           'selector',
           'preset',
           'editor',
           'preview',
           'apply',
           'clear',
           'token_mapper',
           'create_skin',
           'edit_skin',
           'delete_skin',
           'effects',
           'particles',
           'shaders',
           'materials',
           'icons',
           'fonts',
           'colors',
           'background',
           'border',
           'shadow',
           'outline',
           'animation',
           'transition',
           'interaction',
           'layout',
           'responsive',
           'effect_editor',
           'particle_editor',
           'shader_editor',
           'material_editor',
           'icon_editor',
           'font_editor',
           'color_editor',
           'background_editor',
           'border_editor',
           'shadow_editor',
           'outline_editor',
           'payload'],
 'slide_panel': ['bgcolor', 'cross_axis', 'spacing'],
 'slider': ['divisions', 'enabled', 'end', 'max', 'min', 'start'],
 'snack_bar': ['message',
               'label',
               'open',
               'duration_ms',
               'action_label',
               'variant',
               'style',
               'icon',
               'instant',
               'priority',
               'use_flushbar',
               'use_fluttertoast',
               'toast_position',
               'events'],
 'snap_grid': ['background_color', 'color', 'offset'],
 'sortable_header': ['options', 'selected', 'selected_index', 'variant', 'label', 'dense'],
 'spacer': [],
 'spark_plot': ['color', 'max', 'min', 'stroke_width', 'values'],
 'sparkline': [],
 'splash': [],
 'split_pane': ['axis', 'ratio', 'use_split_view'],
 'split_view': ['axis', 'ratio', 'min_ratio', 'max_ratio', 'draggable', 'divider_size'],
 'sprite': [],
 'stack': ['alignment', 'fit', 'clip_behavior'],
 'stagger': [],
 'status_bar': [],
 'sticky_list': [],
 'style': ['style_pack',
           'pack',
           'tokens',
           'token_overrides',
           'style_tokens',
           'recipes',
           'default_style',
           'default_modifiers',
           'default_motion',
           'state',
           'variant',
           'events',
           'child',
           'children'],
 'surface': ['color',
             'bgcolor',
             'elevation',
             'radius',
             'padding',
             'margin',
             'border',
             'border_color',
             'border_width',
             'shadow_color',
             'clip_behavior'],
 'switch': ['options', 'index', 'value', 'enabled', 'dense'],
 'table': ['columns', 'rows'],
 'table_view': ['rows',
                'headers',
                'columns',
                'sortable',
                'filterable',
                'selectable',
                'multi_select',
                'dense',
                'striped',
                'show_header'],
 'tabs': ['closable', 'index', 'labels', 'scrollable', 'show_add'],
 'text': [],
 'text_area': [],
 'text_button': [],
 'text_field': [],
 'time_select': ['enabled', 'label', 'placeholder', 'use_24h', 'value'],
 'timeline': [],
 'toast': ['action_label',
           'duration_ms',
           'icon',
           'instant',
           'label',
           'message',
           'open',
           'priority',
           'style',
           'variant',
           'use_flushbar',
           'use_fluttertoast',
           'toast_position'],
 'toast_host': [],
 'tooltip': ['message', 'prefer_below', 'text', 'wait_ms'],
 'top_bar': ['bgcolor', 'center_title', 'elevation', 'subtitle', 'title'],
 'transition': ['duration_ms', 'curve', 'transition_type', 'preset', 'state', 'mode', 'enabled', 'child', 'children'],
 'vertical_divider': ['vertical', 'thickness', 'indent', 'end_indent', 'color'],
 'video': [],
 'vignette': ['enabled', 'intensity', 'radius', 'softness', 'color', 'blend_mode'],
 'virtual_grid': [],
 'virtual_list': ['items',
                  'header',
                  'footer',
                  'scrollable',
                  'separator',
                  'spacing',
                  'padding',
                  'reverse',
                  'item_extent',
                  'cache_extent',
                  'loading',
                  'skeleton_count',
                  'has_more',
                  'prefetch_threshold',
                  'use_positioned_list',
                  'initial_index'],
 'visual_fx': [],
 'webview': ['url',
             'html',
             'base_url',
             'bgcolor',
             'engine',
             'webview_engine',
             'fallback_engine',
             'use_inapp',
             'prevent_links',
             'request_headers',
             'headers',
             'user_agent',
             'javascript_enabled',
             'js_enabled',
             'dom_storage_enabled',
             'third_party_cookies_enabled',
             'cache_enabled',
             'clear_cache_on_start',
             'incognito',
             'media_playback_requires_user_gesture',
             'allows_inline_media_playback',
             'allow_file_access',
             'allow_universal_access_from_file_urls',
             'allow_popups',
             'open_external_links',
             'init_timeout_ms'],
 'window_controls': [],
 'window_drag_region': ['draggable',
                        'maximize_on_double_tap',
                        'emit_move',
                        'native_drag',
                        'native_maximize_action',
                        'child'],
 'window_frame': ['title',
                  'show_close',
                  'show_maximize',
                  'show_minimize',
                  'draggable',
                  'acrylic_effect',
                  'acrylic_opacity',
                  'content_padding',
                  'title_height',
                  'custom_frame',
                  'use_native_title_bar',
                  'native_title_bar',
                  'system_title_bar',
                  'native_window_actions',
                  'window_actions',
                  'show_default_controls',
                  'title_leading',
                  'title_content',
                  'title_widget',
                  'title_trailing',
                  'window_controls',
                  'child'],
 'wrap': ['spacing',
          'run_spacing',
          'alignment',
          'run_alignment',
          'cross_alignment',
          'direction',
          'vertical_direction',
          'clip_behavior']}

RUNTIME_PROP_HINTS.setdefault(
    "candy_scope",
    [
        "tokens",
        "theme",
        "brightness",
        "child",
        "children",
        "particles",
        "scanline",
        "shimmer",
        "vignette",
    ],
)
RUNTIME_PROP_HINTS.setdefault(
    "skins_scope",
    ["skin", "tokens", "brightness", "child", "children"],
)

# Ensure every shared control has schema + hint map, and hint props are visible
# to strict-mode signatures/introspection.
for _name in _BOTH_ENDS_CONTROL_TYPES:
    schema = CONTROL_SCHEMAS.setdefault(_name, _control_schema())
    hints = RUNTIME_PROP_HINTS.setdefault(_name, [])
    schema_props = schema.setdefault("properties", {})
    for prop in hints:
        schema_props.setdefault(prop, ANY_SCHEMA)

# Exported/consumed by core control signature plumbing.
_ALL_CONTROL_TYPES = set(_BOTH_ENDS_CONTROL_TYPES)

for name, schema in list(CONTROL_SCHEMAS.items()):
    CONTROL_SCHEMAS[name] = _merge_universal(_merge_layout(schema))
