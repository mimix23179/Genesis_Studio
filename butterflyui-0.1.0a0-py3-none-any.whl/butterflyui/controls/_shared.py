from __future__ import annotations

from collections.abc import Iterable, Mapping
from typing import Any

from ..core.control import Component as CoreComponent


def _normalize_token(value: str) -> str:
    return value.strip().lower().replace("-", "_").replace(" ", "_")


def _canonical_control_type(value: str) -> str:
    normalized = _normalize_token(value)
    if normalized in {"container", "box"}:
        return "surface"
    return normalized


_INTERACTIVE_CONTROLS = {
    "candy",
    "skins",
    "style",
    "modifier",
    "button",
    "elevated_button",
    "filled_button",
    "outlined_button",
    "text_button",
    "checkbox",
    "switch",
    "slider",
    "text_field",
    "radio",
    "select",
    "combo_box",
    "date_picker",
    "chip",
    "file_picker",
    "directory_picker",
    "tabs",
    "menu_item",
    "list_tile",
    "item_tile",
    "pagination",
    "notification_center",
    "snack_bar",
    "drawer",
    "sidebar",
    "alert_dialog",
    "bubble",
    "display",
}

_GLASS_CONTROLS = {
    "candy",
    "style",
    "modifier",
    "surface",
    "box",
    "container",
    "card",
    "row",
    "column",
    "stack",
    "wrap",
    "scroll_view",
    "split_view",
    "split_pane",
    "pane",
    "grid_view",
    "virtual_grid",
    "list_view",
    "virtual_list",
    "table",
    "data_table",
    "data_grid",
    "table_view",
    "overlay",
    "alert_dialog",
    "popover",
    "portal",
    "context_menu",
    "tooltip",
    "toast",
    "toast_host",
    "window_frame",
}

_TRANSITION_CONTROLS = {
    "candy",
    "style",
    "modifier",
    "overlay",
    "alert_dialog",
    "popover",
    "portal",
    "context_menu",
    "tooltip",
    "toast",
    "toast_host",
    "slide_panel",
}

_INTERACTIVE_MODIFIERS = {
    "hovereffectmodifier",
    "hovereffect",
    "hover_lift",
    "hoverlift",
    "presseffectmodifier",
    "presseffect",
    "press_scale",
    "pressscale",
    "focusringmodifier",
    "focusring",
    "focus_ring",
    "elevationmodifier",
    "elevation",
    "clickburstmodifier",
    "clickburst",
    "click_burst",
    "burstparticles",
    "soundmodifier",
    "sound",
    "soundonclick",
    "hapticsmodifier",
    "haptics",
}

_GLASS_MODIFIERS = {
    "glassmodifier",
    "glass",
    "glass_overlay",
    "glassoverlay",
}

_TRANSITION_MODIFIERS = {
    "transitionmodifier",
    "transition",
}

_MODIFIER_CAPABILITIES_MANIFEST_VERSION = 1


def modifier_capabilities_manifest() -> dict[str, Any]:
    return {
        "version": _MODIFIER_CAPABILITIES_MANIFEST_VERSION,
        "controls": {
            "interactive": sorted(_INTERACTIVE_CONTROLS),
            "glass": sorted(_GLASS_CONTROLS),
            "transition": sorted(_TRANSITION_CONTROLS),
        },
        "modifiers": {
            "interactive": sorted(_INTERACTIVE_MODIFIERS),
            "glass": sorted(_GLASS_MODIFIERS),
            "transition": sorted(_TRANSITION_MODIFIERS),
        },
    }


def _modifier_type(value: Any) -> str:
    if isinstance(value, str):
        return _normalize_token(value)
    if isinstance(value, Mapping):
        raw = value.get("type") or value.get("id") or value.get("name")
        if raw is None:
            return ""
        return _normalize_token(str(raw))
    return ""


def _sanitize_modifiers_for_control(control_type: str, modifiers: Any) -> list[Any]:
    if not isinstance(modifiers, Iterable) or isinstance(modifiers, (str, bytes, Mapping)):
        return []

    normalized_control = _canonical_control_type(control_type)
    allow_interactive = normalized_control in _INTERACTIVE_CONTROLS
    allow_glass = normalized_control in _GLASS_CONTROLS
    allow_transition = normalized_control in _TRANSITION_CONTROLS

    filtered: list[Any] = []
    for modifier in modifiers:
        kind = _modifier_type(modifier)
        if not kind:
            filtered.append(modifier)
            continue
        if kind in _INTERACTIVE_MODIFIERS and not allow_interactive:
            continue
        if kind in _GLASS_MODIFIERS and not allow_glass:
            continue
        if kind in _TRANSITION_MODIFIERS and not allow_transition:
            continue
        filtered.append(modifier)
    return filtered


def _normalize_component_props(props: Mapping[str, Any] | None) -> dict[str, Any]:
    return dict(props or {})


def merge_props(
    props: Mapping[str, Any] | None = None,
    **kwargs: Any,
) -> dict[str, Any]:
    out: dict[str, Any] = {}
    if isinstance(props, Mapping):
        out.update(dict(props))
    for key, value in kwargs.items():
        if value is not None:
            out[key] = value
    return out


def collect_children(
    positional: tuple[Any, ...],
    *,
    child: Any | None = None,
    children: Iterable[Any] | None = None,
) -> list[Any]:
    out = [item for item in positional if item is not None]
    if child is not None:
        out.append(child)
    if children is not None:
        out.extend(item for item in children if item is not None)
    return out


class Component(CoreComponent):
    """Base class for all Python-side ButterflyUI controls.

    Any non-``None`` keyword arguments are merged into the outgoing
    ``props`` payload. Combined with control-level constructors and
    core ``Control`` auto-backfill, this keeps Python docstring/init args
    and Dart runtime props loosely coupled: newly added runtime
    properties can be forwarded without waiting for per-control rewrites.
    """
    control_type: str = ""

    def __init__(
        self,
        *children_args: Any,
        child: Any | None = None,
        children: Iterable[Any] | None = None,
        props: Mapping[str, Any] | None = None,
        style: Mapping[str, Any] | None = None,
        variant: Any | None = None,
        modifiers: Iterable[Any] | None = None,
        motion: Any | None = None,
        style_slots: Mapping[str, Any] | None = None,
        state: str | None = None,
        strict: bool = False,
        **kwargs: Any,
    ) -> None:
        inline_handlers: dict[str, Any] = {}
        for key in list(kwargs):
            value = kwargs.get(key)
            if not callable(value):
                continue
            if key.startswith("on_") and len(key) > 3:
                inline_handlers[key[3:]] = value
                kwargs.pop(key, None)
                continue
            if key == "action":
                inline_handlers["click"] = value
                kwargs.pop(key, None)

        control_props = merge_props(
            props,
            variant=variant,
            motion=motion,
            state=state,
            **kwargs,
        )
        control_props = _normalize_component_props(control_props)
        inferred_style_slots: Mapping[str, Any] | None = None
        if style_slots is None:
            candidate = control_props.pop("style_slots", None)
            if isinstance(candidate, Mapping):
                inferred_style_slots = candidate
        else:
            control_props.pop("style_slots", None)
        resolved_style_slots = style_slots or inferred_style_slots
        if modifiers is not None:
            control_props["modifiers"] = _sanitize_modifiers_for_control(
                self.control_type,
                list(modifiers),
            )
        local_style: dict[str, Any] = {}
        existing_style = control_props.get("style")
        if isinstance(existing_style, Mapping):
            local_style.update(dict(existing_style))

        style_map: dict[str, Any] | None = None
        if isinstance(style, Mapping):
            style_map = dict(style)
        elif style is not None and hasattr(style, "to_json"):
            try:
                payload = style.to_json()
                if isinstance(payload, Mapping):
                    style_map = dict(payload)
            except Exception:
                style_map = None
        if style_map:
            local_style.update(style_map)
        if resolved_style_slots is not None:
            slots = local_style.get("slots")
            slot_map = dict(slots) if isinstance(slots, Mapping) else {}
            slot_map.update(dict(resolved_style_slots))
            local_style["slots"] = slot_map
        if local_style:
            # Keep backward compatibility for `style=` while also exposing
            # the explicit local-style contract used by the style resolver.
            control_props["style"] = local_style

        if "modifiers" in control_props:
            control_props["modifiers"] = _sanitize_modifiers_for_control(
                self.control_type,
                control_props.get("modifiers"),
            )
        control_children = collect_children(
            children_args,
            child=child,
            children=children,
        )
        super().__init__(
            control_type=self.control_type,
            props=control_props,
            children=control_children,
            style=style,
            strict=strict,
        )
        for event, handler in inline_handlers.items():
            self.add_inline_event_handler(event, handler)


