from __future__ import annotations
from collections.abc import Mapping
from typing import Any
from ..base_control import butterfly_control
from ..layout_control import LayoutControl

from ..multi_child_control import MultiChildControl
__all__ = ["SplitView"]

@butterfly_control('split_view', field_aliases={'controls': 'children'})
class SplitView(LayoutControl, MultiChildControl):
    """
    Two-panel layout split along a horizontal or vertical axis.

    The runtime renders two children separated by a divider. ``axis`` sets
    the split direction; ``ratio`` sets the initial fractional split position
    (0.0-1.0). ``draggable`` enables the user to drag the divider.
    ``divider_size`` controls the visible width or height of the divider.
    For bounded drag behavior prefer ``SplitPane``.

    Example:

    ```python
    import butterflyui as bui

    bui.SplitView(
        bui.Text("Left"),
        bui.Text("Right"),
        axis="horizontal",
        ratio=0.5,
        draggable=True,
    )
    ```
    """

    axis: str | None = None
    """
    Split direction. Values: ``"horizontal"``, ``"vertical"``.
    """

    ratio: float | None = None
    """
    Initial fractional position of the divider (0.0-1.0).
    """

    min_ratio: float | None = None
    """
    Minimum allowed divider ratio during drag.
    """

    max_ratio: float | None = None
    """
    Maximum allowed divider ratio during drag.
    """

    draggable: bool | None = None
    """
    When ``True`` the user can drag the divider to resize panels.
    """

    divider_size: float | None = None
    """
    Width or height of the divider affordance in logical pixels.
    """
