from __future__ import annotations
from collections.abc import Mapping
from typing import Any
from ..base_control import butterfly_control
from ..layout_control import LayoutControl

from ..multi_child_control import MultiChildControl
__all__ = ["MenuBar"]

@butterfly_control('menu_bar', field_aliases={'controls': 'children'})
class MenuBar(LayoutControl, MultiChildControl):
    """
    Application-level horizontal menu bar with dropdown menu groups.

    ``MenuBar`` accepts ``menus`` or ``items`` payloads. Each top-level menu
    can include nested actions, separators, shortcuts, icons, and custom
    payload metadata. Runtime emits ``open``, ``dismiss``, ``select``, and
    ``change`` events as users interact with menu groups.

    The control also supports shared layout/placement hints through ``props``
    (alignment, margin, size constraints, radius, clip behavior).

    Example:

    ```python
    import butterflyui as bui

    bui.MenuBar(
        menus=[
            {
                "id": "file",
                "label": "File",
                "items": [
                    {"id": "new", "label": "New", "shortcut": "Ctrl+N"},
                    {"id": "open", "label": "Open"},
                    {"separator": True},
                    {"id": "quit", "label": "Quit", "variant": "danger"},
                ],
            },
            {
                "id": "edit",
                "label": "Edit",
                "items": [{"id": "undo", "label": "Undo", "shortcut": "Ctrl+Z"}],
            },
        ],
        events=["open", "select", "change"],
    )
    ```
    """

    menus: list[Mapping[str, Any]] | None = None
    """
    List of top-level menu spec mappings.
    """

    dense: bool | None = None
    """
    Reduces bar height and menu item padding.
    """

    item_bgcolor: Any | None = None
    """
    Item bgcolor value forwarded to the `menu_bar` runtime control.
    """

    divider_color: Any | None = None
    """
    Divider color value forwarded to the `menu_bar` runtime control.
    """

    backdrop: Any | None = None
    """
    Backdrop value forwarded to the `menu_bar` runtime control.
    """

    backdrop_blur: Any | None = None
    """
    Backdrop blur value forwarded to the `menu_bar` runtime control.
    """

    use_menu_bar: Any | None = None
    """
    Use menu bar value forwarded to the `menu_bar` runtime control.
    """

    use_mac_menu_bar: Any | None = None
    """
    Use mac menu bar value forwarded to the `menu_bar` runtime control.
    """

    align: Any | None = None
    """
    Align value forwarded to the `menu_bar` runtime control.
    """

    position: Any | None = None
    """
    Position value forwarded to the `menu_bar` runtime control.
    """

    panel_margin: Any | None = None
    """
    Panel margin value forwarded to the `menu_bar` runtime control.
    """

    panel_alignment: Any | None = None
    """
    Panel alignment value forwarded to the `menu_bar` runtime control.
    """

    panel_width: Any | None = None
    """
    Panel width value forwarded to the `menu_bar` runtime control.
    """

    panel_min_width: Any | None = None
    """
    Panel min width value forwarded to the `menu_bar` runtime control.
    """

    panel_max_width: Any | None = None
    """
    Panel max width value forwarded to the `menu_bar` runtime control.
    """

    offset: Any | None = None
    """
    Offset applied by the runtime when positioning this control.
    """

    translate: Any | None = None
    """
    Translate value forwarded to the `menu_bar` runtime control.
    """

    def set_menus(self, session: Any, menus: list[Mapping[str, Any]]) -> dict[str, Any]:
        return self.invoke(
            session,
            "set_menus",
            {"menus": [dict(menu) for menu in menus]},
        )

    def set_items(self, session: Any, items: list[Mapping[str, Any]]) -> dict[str, Any]:
        return self.invoke(
            session,
            "set_items",
            {"items": [dict(item) for item in items]},
        )

    def set_props(self, session: Any, **props: Any) -> dict[str, Any]:
        return self.invoke(session, "set_props", {"props": props})

    def get_state(self, session: Any) -> dict[str, Any]:
        return self.invoke(session, "get_state", {})

    def emit(self, session: Any, event: str, payload: Mapping[str, Any] | None = None) -> dict[str, Any]:
        return self.invoke(session, "emit", {"event": event, "payload": dict(payload or {})})

    def trigger(self, session: Any, event: str = "change", **payload: Any) -> dict[str, Any]:
        return self.emit(session, event, payload)
