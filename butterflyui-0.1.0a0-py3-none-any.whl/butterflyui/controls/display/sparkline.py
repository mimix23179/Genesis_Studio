from __future__ import annotations
from collections.abc import Mapping
from typing import Any
from ..base_control import butterfly_control
from ..layout_control import LayoutControl

__all__ = ["Sparkline"]

@butterfly_control('sparkline')
class Sparkline(LayoutControl):
    """
    Compact inline line chart for trend visualisation.

    Renders a small ``CustomPaint`` polyline (default height 40 px)
    using ``_LineChartPainter``.  Intended for dashboard cells,
    table rows, or anywhere a quick numeric trend is needed.  When
    ``fill`` is ``True`` the area under the line is shaded at
    reduced opacity.

    Use ``set_data`` to update the data points at runtime.

    Example:

    ```python
    import butterflyui as bui

    spark = bui.Sparkline(
        values=[3, 7, 4, 8, 2, 6],
        color="#4f46e5",
        fill=True,
    )
    ```
    """

    values: list[Any] | None = None
    """
    Numeric data points for the sparkline.
    """

    points: list[Any] | None = None
    """
    Backward-compatible alias for ``values``. When both fields are provided, ``values`` takes precedence and this alias is kept only for compatibility.
    """

    fill: bool | None = None
    """
    Controls whether the area under the line is shaded. Set it to ``False`` to disable this behavior.
    """

    def set_data(self, session: Any, values: list[Any]) -> dict[str, Any]:
        return self.invoke(session, "set_data", {"values": values})

    def emit(self, session: Any, event: str, payload: Mapping[str, Any] | None = None) -> dict[str, Any]:
        return self.invoke(session, "emit", {"event": event, "payload": dict(payload or {})})
