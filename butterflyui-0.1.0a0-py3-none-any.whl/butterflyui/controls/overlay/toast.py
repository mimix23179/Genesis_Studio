from __future__ import annotations
from collections.abc import Mapping
from typing import Any
from ..base_control import butterfly_control
from ..overlay_control import OverlayControl

__all__ = ["Toast"]

@butterfly_control('toast', positional_fields=('message',))
class Toast(OverlayControl):
    """
    Ephemeral notification toast that appears briefly and auto-dismisses.

    The runtime renders a transient message overlay. ``message`` sets the
    notification text. ``open`` controls visibility. ``duration_ms`` sets
    the auto-dismiss delay. ``action_label`` adds an inline action button.
    ``variant`` applies a semantic color scheme.

    Example:

    ```python
    import butterflyui as bui

    bui.Toast(
        message="Changes saved!",
        open=True,
        duration_ms=3000,
        variant="success",
    )
    ```
    """

    message: str | None = None
    """
    Main message text rendered inside the control.
    """

    duration_ms: int | None = None
    """
    Milliseconds before the toast auto-dismisses. Use ``0`` to
    disable auto-dismiss.
    """

    action_label: str | None = None
    """
    Label for an optional inline action button.
    """

    instant: Any | None = None
    """
    Instant value forwarded to the `toast` runtime control.
    """

    label: Any | None = None
    """
    Primary label rendered by the control.
    """

    priority: Any | None = None
    """
    Priority value forwarded to the `toast` runtime control.
    """

    use_flushbar: Any | None = None
    """
    Use flushbar value forwarded to the `toast` runtime control.
    """

    use_fluttertoast: Any | None = None
    """
    Use fluttertoast value forwarded to the `toast` runtime control.
    """

    toast_position: Any | None = None
    """
    Toast position value forwarded to the `toast` runtime control.
    """

    def set_open(self, session: Any, value: bool) -> dict[str, Any]:
        return self.invoke(session, "set_open", {"value": value})

    def show(self, session: Any) -> dict[str, Any]:
        return self.invoke(session, "set_open", {"value": True})

    def hide(self, session: Any) -> dict[str, Any]:
        return self.invoke(session, "set_open", {"value": False})

    def get_state(self, session: Any) -> dict[str, Any]:
        return self.invoke(session, "get_state", {})

    def set_props(self, session: Any, **props: Any) -> dict[str, Any]:
        return self.invoke(session, "set_props", {"props": props})

    def emit(self, session: Any, event: str, payload: Mapping[str, Any] | None = None) -> dict[str, Any]:
        return self.invoke(session, "emit", {"event": event, "payload": dict(payload or {})})

    def trigger(self, session: Any, event: str = "action", **payload: Any) -> dict[str, Any]:
        return self.emit(session, event, payload)
