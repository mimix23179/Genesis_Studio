from __future__ import annotations

from ..customization.histogram_view import HistogramView

__all__ = ["HistogramView"]
