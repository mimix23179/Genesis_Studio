from __future__ import annotations

from ..registry import control_specs_for_category

CONTROL_SPECS = control_specs_for_category("interaction")

__all__ = ["CONTROL_SPECS"]
