"""ButterflyUI Python SDK.

ButterflyUI is a UI app-building package driven by a ButterflyUI Flutter runtime.
Python controls the runtime through a live session channel.
"""

from __future__ import annotations

from .version import get_version, __version__

# Automatically initialize 60 FPS performance when ButterflyUI is imported
from .core.performance import PerformanceConfig

PerformanceConfig.initialize()

from .app import (
    App,
    AppConfig,
    BaseApp,
    ButterflyUIDesktop,
    ButterflyUIError,
    ButterflyUISession,
    ButterflyUIWeb,
    Page,
    RunTarget,
    RuntimeApp,
    RuntimePlan,
    app,
    run,
    run_desktop,
    run_web,
)
from .core import (
    Breakpoints,
    Component,
    Control,
)
from .icons import (
    ICON_NAMES,
    ICON_SET,
    IconData,
    Icons,
    icon,
    icon_names,
    is_icon_name,
    normalize_icon_name,
    normalize_icon_value,
    suggest_icon_names,
)
from .metadata import CONTROL_SPECS, get_control_spec, iter_control_specs
from .stylesheet import StyleRule, StyleSelector, StyleSheet, parse_stylesheet
from .types import (
    Alignment,
    AnimationSpec,
    BorderSideSpec,
    BorderSpec,
    BorderTokens,
    BoxShadow,
    ColorTokens,
    ColorRGBA,
    DepthTokens,
    DecorationImage,
    GradientWash,
    EdgeInsets,
    LineField,
    LinearGradient,
    LottieLayer,
    MotionTokens,
    NoiseField,
    OrbitField,
    ParticleField,
    RadialGradient,
    RadiusTokens,
    RiveLayer,
    SceneMask,
    SceneRegion,
    SceneLayer,
    ShaderLayer,
    ShadowTokens,
    SpacingTokens,
    SemanticsProps,
    Style,
    StyleTokens,
    StyleValue,
    SweepGradient,
    TextStyle,
    TypographyRole,
    TypographyTokens,
)
from .core.performance import PerformanceConfig, performance_config, enable_60fps
from .controls import *  # noqa: F401,F403
from .controls import __all__ as _controls_all
from .state import Computed, DerivedState, Signal, State, effect
from .callbacks import Update, update, NO_UPDATE, TaskQueue, Progress as ProgressHandle, bind_event
from .assets import AssetServer, data_uri_from_base64, file_payload_to_src, files_payload_to_srcs

__all__ = [
    "get_version",
    "__version__",
    "AppConfig",
    "RuntimeApp",
    "App",
    "Page",
    "BaseApp",
    "ButterflyUIWeb",
    "ButterflyUIDesktop",
    "ButterflyUISession",
    "ButterflyUIError",
    "RunTarget",
    "RuntimePlan",
    "run",
    "app",
    "run_web",
    "run_desktop",
    "Component",
    "Control",
    "Breakpoints",
    "IconData",
    "ICON_NAMES",
    "ICON_SET",
    "Icons",
    "icon",
    "icon_names",
    "is_icon_name",
    "normalize_icon_name",
    "normalize_icon_value",
    "suggest_icon_names",
    "Alignment",
    "AnimationSpec",
    "BorderSpec",
    "BorderSideSpec",
    "BorderTokens",
    "BoxShadow",
    "ColorTokens",
    "ColorRGBA",
    "DecorationImage",
    "DepthTokens",
    "EdgeInsets",
    "GradientWash",
    "LinearGradient",
    "LineField",
    "LottieLayer",
    "MotionTokens",
    "NoiseField",
    "OrbitField",
    "ParticleField",
    "RadialGradient",
    "RadiusTokens",
    "RiveLayer",
    "SceneMask",
    "SceneRegion",
    "SceneLayer",
    "ShaderLayer",
    "SemanticsProps",
    "Style",
    "StyleTokens",
    "StyleValue",
    "PerformanceConfig",
    "performance_config",
    "enable_60fps",
    "SweepGradient",
    "TextStyle",
    "TypographyRole",
    "TypographyTokens",
    "StyleSelector",
    "StyleRule",
    "StyleSheet",
    "parse_stylesheet",
    "CONTROL_SPECS",
    "get_control_spec",
    "iter_control_specs",
    "State",
    "DerivedState",
    "Signal",
    "Computed",
    "effect",
    "Update",
    "update",
    "NO_UPDATE",
    "TaskQueue",
    "ProgressHandle",
    "bind_event",
    "AssetServer",
    "data_uri_from_base64",
    "file_payload_to_src",
    "files_payload_to_srcs",
]

for _name in _controls_all:
    if _name not in __all__:
        __all__.append(_name)
